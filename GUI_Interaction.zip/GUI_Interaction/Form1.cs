﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Interaction
{
    public partial class Form1 : Form
    {
        public int Longueur = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculLongueur(object sender, EventArgs e)

        {
            Longueur = txtNom.TextLength;
            txtResult.Text = txtNom.Text + " contient " + Convert.ToString(Longueur) + " caractère !";
        }

        private void Ca(object sender, KeyEventArgs e)
        {
            Longueur = txtNom.TextLength;
            txtResult.Text = txtNom.Text + " contient " + Convert.ToString(Longueur) + " caractère !";
        }
    }
}
