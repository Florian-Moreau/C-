﻿namespace MaPremiereFenetre
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.b_Message = new System.Windows.Forms.Button();
            this.tNom = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cliquez sur le bouton ci-dessous.";
            // 
            // b_Message
            // 
            this.b_Message.Location = new System.Drawing.Point(88, 107);
            this.b_Message.Name = "b_Message";
            this.b_Message.Size = new System.Drawing.Size(75, 23);
            this.b_Message.TabIndex = 1;
            this.b_Message.Text = "Clic me !";
            this.b_Message.UseVisualStyleBackColor = true;
            this.b_Message.Click += new System.EventHandler(this.Afficher_Message);
            // 
            // tNom
            // 
            this.tNom.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.tNom.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.tNom.Location = new System.Drawing.Point(11, 57);
            this.tNom.Name = "tNom";
            this.tNom.Size = new System.Drawing.Size(228, 20);
            this.tNom.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Saisissez votre nom";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(252, 166);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tNom);
            this.Controls.Add(this.b_Message);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Ma Première Fenêtre";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button b_Message;
        private System.Windows.Forms.TextBox tNom;
        private System.Windows.Forms.Label label2;
    }
}

