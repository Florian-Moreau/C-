﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tabBillets = { 500, 200, 100, 50, 20, 10, 5, 2, 1 };
            String[] type = { "billet", "billet", "billet", "billet", "billet", "billet", "billet", "piece", "piece" };
            Console.WriteLine("Quel est le montant total de vos achats ?");
            int prixAchat = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Quel montant avez-vous donné ?");
            int prixDonne = Convert.ToInt32(Console.ReadLine());

            if (prixDonne < prixAchat)
            {
                Console.WriteLine("Au voleur !");
            }
            else if (prixDonne > prixAchat)
            {

                int reste = prixDonne - prixAchat;
                Console.WriteLine("Nous vous devons " + reste + " euro");

                for (int i = 0; i < tabBillets.Length; i++)
                {
                    int nombre;
                    nombre = reste / tabBillets[i];

                    if (nombre > 0)
                    {
                        Console.WriteLine("On vous rend " + nombre + " fois " + tabBillets[i] + " euro en " + type[i]);
                        reste = reste % tabBillets[i];
                    }
                }

            }
            else {
                Console.WriteLine("C'est bon mamene!");
            }
            Console.ReadKey();
        }
    }
}
