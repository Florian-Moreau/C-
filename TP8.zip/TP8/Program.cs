﻿/* TP8
 * Auteur : Florian MOREAU 
 * Date : 2018-01-12 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP8
{
    class Program
    {
        static float moyenne(int a, int b, int c)
        {
            int res = (a + b + c) / 3;
            return res;
        }

        static string lien(string a, string b)
        {
            String lier = a +" "+ b;
            return lier;
        }

        static string separe(string text)
        {
            String textsepar = "";
            for (int i = 0; i < text.Length; ++i)
                textsepar= textsepar + "-" + text[i];
            return textsepar;
        }
        static string rassemble(string a, string b)
        {
            String tampon = lien(a, b);
            String res = separe(tampon);
            return res;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("////////// Exercice 1 //////////");

            Console.WriteLine("Saisir un nombre entier pour faire une moyenne : ");
            int chiffre1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Saisir un second nombre entier pour faire une moyenne : ");
            int chiffre2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Saisir un dernier nombre entier pour faire une moyenne : ");
            int chiffre3 = Convert.ToInt32(Console.ReadLine());
            
            float moyen = moyenne(chiffre1, chiffre2, chiffre3);
            Console.WriteLine("La moyenne de "+chiffre1+" / "+chiffre2+" / "+chiffre3+" est de "+moyen);

            Console.WriteLine("////////// Exercice 2 //////////");
            Console.WriteLine("Entrer un mot");
            string text1 = (Console.ReadLine());
            Console.WriteLine("Entrer un second mot");
            string text2 = (Console.ReadLine());

            String lie = lien(text1, text2);
            Console.WriteLine("On lie les deux textes et on obtient : " + lie);

            Console.WriteLine("////////// Exercice 3 //////////");
            Console.WriteLine("Entrer un mot");
            string text3 = (Console.ReadLine());

            String textlier = separe(text3);

            Console.WriteLine("On sépare le tout : " + textlier);

            Console.WriteLine("////////// Exercice 4 //////////");
            Console.WriteLine("Entrer un mot");
            string text4 = (Console.ReadLine());
            Console.WriteLine("Entrer un second mot");
            string text5 = (Console.ReadLine());

            String ras = rassemble(text4, text5);
            Console.WriteLine("Voici le résultat : " + ras);

            Console.ReadKey();
        }
    }
}
