﻿/* Ce programme est le jeu du plus grand plus petit
 * Auteur : Florian MOREAU 
 * Pseudo : Lethfy
 * Date : 2017-10-15 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP05
{
    class Program
    {
        static void Main(string[] args)
        {
            float c1 = 0;
            float c2 = 0;
            float c3 = 0;
            float max = 0;
            float x1 = 0; // première valeur de l'ordre croissant
            float x2 = 0; // deuxième valeur de l'ordre croissant
            float x3 = 0; // troisième valeur de l'ordre croissant
            int y1 = 0;  // première capteur de l'ordre croissant
            int y2 = 0; // première capteur de l'ordre croissant
            int y3 = 0; // première capteur de l'ordre croissant
            String cSaisie = "";

            Console.WriteLine("Données du capteur 1"); // Simule l'envois de donnée du capteur 1
            cSaisie = Console.ReadLine();
            c1 = Convert.ToSingle(cSaisie); // Passer de String à Float

            Console.WriteLine("Données du capteur 2"); // Simule l'envois de donnée du capteur 2
            cSaisie = Console.ReadLine();
            c2 = Convert.ToSingle(cSaisie); // Passer de String à Float

            Console.WriteLine("Données du capteur 3"); // Simule l'envois de donnée du capteur 3
            cSaisie = Console.ReadLine();
            c3 = Convert.ToSingle(cSaisie); // Passer de String à Float

            // On test toutes les valeurs
            if (c1 > max)
            {
                max = c1;
                cSaisie = "capteur 1";
            }
            if (c2 > max)
            {
                max = c2;
                cSaisie = "capteur 2";
            }
            if (c3 > max)
            {
                max = c3;
                cSaisie = "capteur 3";
            }

            Console.WriteLine("Le " + cSaisie + " est le capteur avec la plus grande valeur enregistré, qui est de " + max + " cm."); // Valeur max trouvé

            //On classe les valeurs dans l'ordre croissant
            if ((c1 > c2) & (c2 > c3))
            {
                x1 = c1; // Valeur de capteur
                y1 = 1; // Numéro de capteur
                x2 = c2;
                y2 = 2;
                x3 = c3;
                y3 = 3;

            }

            else if (c1 > c3 & c3 > c2)
            {
                x1 = c1;
                y1 = 1;
                x2 = c3;
                y2 = 3;
                x3 = c2;
                y3 = 2;
            }
            else if (c2 > c1 & c1 > c3)
            {
                x1 = c2;
                y1 = 2;
                x2 = c1;
                y2 = 1;
                x3 = c3;
                y3 = 3;
            }
            else if (c2 > c3 & c3 > c1)
            {
                x1 = c2;
                y1 = 2;
                x2 = c3;
                y2 = 3;
                x3 = c1;
                y3 = 1;
            }
            else if (c3 > c1 & c1 > c2)
            {
                x1 = c3;
                y1 = 3;
                x2 = c1;
                y2 = 1;
                x3 = c2;
                y3 = 2;
            }
            else if (c3 > c1 & c2 > c1)
            {
                x1 = c3;
                y1 = 3;
                x2 = c2;
                y2 = 2;
                x3 = c1;
                y3 = 1;
            }
            Console.WriteLine("Voici les nombres dans l'ordre croissant : Capteur " + y1 + " = " + x3 + " Capteur " + y2 + " = " + x2 + " Capteur " + y3 + " = " + x1);
            Console.ReadKey();
        }
    }
}
