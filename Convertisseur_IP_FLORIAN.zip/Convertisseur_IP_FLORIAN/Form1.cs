﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace comparateur_IP_FLORIAN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String[] nombreIP1 = ip_1.Text.Split('.');
            String[] nombreIP2 = ip_2.Text.Split('.');
            String[] nombre_masque = mask.Text.Split('.');
            int i = 0;
            int[] ip1 = { 0, 0, 0, 0 };
            int[] ip2 = { 0, 0, 0, 0 };
            int[] réseau1 = { 0, 0, 0, 0 };
            int[] réseau2 = { 0, 0, 0, 0 };
            int[] masque = { 0, 0, 0, 0 };
            int count_true = 0;
            while (i < 4)
            {
                ip1[i] = Convert.ToInt16(nombreIP1[i]);
                ip2[i] = Convert.ToInt16(nombreIP2[i]);
                masque[i] = Convert.ToInt16(nombre_masque[i]);
                réseau1[i] = ip1[i] & masque[i];
                réseau2[i] = ip2[i] & masque[i];
                if (réseau1[i] == réseau2[i])
                {
                    count_true = count_true + 1;
                }
                else
                {
                    count_true = count_true - 1;
                }
                i = i + 1;
            }
            if (count_true == 4)
            {
                MessageBox.Show("Les deux IPs sont du même réseau");
            }
            else
            {
                MessageBox.Show("Les deux IPs n'appartiennent pas au même réseau");
            }
        }

        private void ip_2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
