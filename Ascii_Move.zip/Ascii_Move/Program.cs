﻿/*
 * Canard en ASCII qui bouge.
 * Crée par SharpDevelop.
 * Créateur : Florian Moreau
 * Date: 8/16/2018
 */
using System;

namespace Ascii_Move
{
	class Program
	{
		public static void Main(string[] args)
			{
				int i = 0;
				int j = 0;
				int largeur = 8;
				int hauteur = 4;
				Console.WriteLine("  __");
				Console.WriteLine("<(o )___");
				Console.WriteLine(" ( ._> /");
				Console.WriteLine("  `---'");
				while (true)
				{
					ConsoleKeyInfo info = Console.ReadKey(true);
					switch (info.Key)
					{
						case ConsoleKey.LeftArrow:
							if( i > 0 )
							{
								Console.MoveBufferArea(i, j, largeur, hauteur, i - 1, j);
								i--;
							}
							break;
						case ConsoleKey.RightArrow:
							if (i < Console.WindowWidth - largeur)
							{
								Console.MoveBufferArea(i, j, largeur, hauteur, i + 1, j);
								i++;
							}
							break;
						case ConsoleKey.UpArrow:
							if( j > 0 )
							{
								Console.MoveBufferArea(i, j, largeur, hauteur, i, j - 1);
								j--;
							}
							break;
						case ConsoleKey.DownArrow:
							Console.MoveBufferArea(i, j, largeur, hauteur, i, j + 1);
							j++;
							break;
					}
					if (info.Key == ConsoleKey.Q)
						break;
				}
		}
	}
}