﻿/*
 * Crée par SharpDevelop.
 * Créateur : Florian Moreau
 * Date: 8/23/2018
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Media;

namespace Music
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}
		
		void B_chimesClick(object sender, EventArgs e)
		{
			SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\chimes.wav"); //Son trouvé dans Windows
			simpleSound.Play(); //On émet le son
		}
		
		void B_errorClick(object sender, EventArgs e)
		{
			SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\Windows Error.wav");
			simpleSound.Play();
		}
	}
}
