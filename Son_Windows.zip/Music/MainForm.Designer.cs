﻿/*
 * Crée par SharpDevelop.
 * Créateur : Florian Moreau
 * Date: 8/23/2018
 */
namespace Music
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button b_chimes;
		private System.Windows.Forms.Button b_error;
		private System.Windows.Forms.GroupBox gb_son;
		private System.Windows.Forms.Label l_info;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.b_chimes = new System.Windows.Forms.Button();
			this.b_error = new System.Windows.Forms.Button();
			this.gb_son = new System.Windows.Forms.GroupBox();
			this.l_info = new System.Windows.Forms.Label();
			this.gb_son.SuspendLayout();
			this.SuspendLayout();
			// 
			// b_chimes
			// 
			this.b_chimes.Location = new System.Drawing.Point(6, 19);
			this.b_chimes.Name = "b_chimes";
			this.b_chimes.Size = new System.Drawing.Size(75, 23);
			this.b_chimes.TabIndex = 0;
			this.b_chimes.Text = "Chimes";
			this.b_chimes.UseVisualStyleBackColor = true;
			this.b_chimes.Click += new System.EventHandler(this.B_chimesClick);
			// 
			// b_error
			// 
			this.b_error.Location = new System.Drawing.Point(5, 48);
			this.b_error.Name = "b_error";
			this.b_error.Size = new System.Drawing.Size(75, 23);
			this.b_error.TabIndex = 1;
			this.b_error.Text = "Error !";
			this.b_error.UseVisualStyleBackColor = true;
			this.b_error.Click += new System.EventHandler(this.B_errorClick);
			// 
			// gb_son
			// 
			this.gb_son.Controls.Add(this.b_chimes);
			this.gb_son.Controls.Add(this.b_error);
			this.gb_son.Location = new System.Drawing.Point(96, 116);
			this.gb_son.Name = "gb_son";
			this.gb_son.Size = new System.Drawing.Size(99, 83);
			this.gb_son.TabIndex = 2;
			this.gb_son.TabStop = false;
			this.gb_son.Text = "Exemple de son";
			// 
			// l_info
			// 
			this.l_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.l_info.Location = new System.Drawing.Point(36, 24);
			this.l_info.Name = "l_info";
			this.l_info.Size = new System.Drawing.Size(216, 57);
			this.l_info.TabIndex = 3;
			this.l_info.Text = "Voici comment faire un son quand on clique sur un bouton avec la galerie de son W" +
	"indows.";
			this.l_info.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 261);
			this.Controls.Add(this.l_info);
			this.Controls.Add(this.gb_son);
			this.Name = "MainForm";
			this.Text = "Music";
			this.gb_son.ResumeLayout(false);
			this.ResumeLayout(false);

		}
	}
}
