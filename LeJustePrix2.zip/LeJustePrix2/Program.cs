﻿/* Ce programme fait choisir un nombre à l'utilisateur
 * Auteur : Florian MOREAU
 * Date : 2017-10-06 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeJustePrix2
{
    class Program
    {
        static void Main(string[] args)
        {
            int compteur=0,           //Compte le nombre d'essaie
                nbAleatoire=0,        // Nombre choisi au hasard
                NbSaisie=0;           //Les variables (attributs)
            String saisieChaine="";    // Pour utiliser Console.ReadLine()
            Random alea = new Random();

            // Début du jeu
            nbAleatoire = alea.Next(0, 100);
            do
            {
                Console.WriteLine("Saisissez un nombre entre 0 et 100");
                saisieChaine = Console.ReadLine();
                NbSaisie = Convert.ToInt32(saisieChaine);

                if (NbSaisie < nbAleatoire)
                {
                    Console.WriteLine("C'est plus grand");
                } else if (NbSaisie > nbAleatoire)
                {
                    Console.WriteLine("C'est plus petit");
                } else
                {
                    Console.WriteLine("Gagné en " + compteur + " fois.");
                }
                //compteur = compteur + 1;
                compteur++;
            } while (NbSaisie != nbAleatoire);
            Console.ReadKey();
        }
    }
}
